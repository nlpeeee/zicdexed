ZicDexed V1.2 card package
Full instructions: docs/README.md ("Install a release on an SD card").
Short version: format a card FAT32, unzip a MiniDexed release (github.com/probonopd/MiniDexed/releases) onto it, then copy the CONTENTS of this folder onto the card root:
  kernel8.img, minidexed.ini, performance.ini   replace the same-named files
  sysex/voice/000090_nasty.syx                  merge into sysex/voice (never replace the folder)
  performance/                                  merge, never overwrite (stock MiniDexed performances, GPL-3.0, from MiniDexed 1277)
  wpa_supplicant.conf.example                   WiFi only: copy to wpa_supplicant.conf and edit
Not included: Yamaha factory banks (build your own with tools/stock_banks.py). WiFi firmware comes with the MiniDexed release, or tools/get-wifi-firmware.*.
